def sum(intarr)
	return 0 if intarr.size == 0
	total = 0
	intarr.each do |i|
		total += i
	end
	return total
end

def max_2_sum(intarr)
	return 0 if intarr.size == 0
	return intarr[0] if intarr.size == 1
	intarr.sort! {|i, j| j <=> i}
	sum = intarr[0] + intarr[1]
end

def sum_to_n?(intarr, n)
	return false if intarr.size == 0 || intarr.size == 1
	if intarr.combination(2).find{|i, j| i + j == n}
		return true
	else 
		return false
	end	
end

#method 1
raise 'sum([]) != 0' unless sum([]) == 0
raise 'sum([1,2,3]) !=6' unless sum([1,2,3]) == 6
raise 'sum([1,2,3,4]) != 10' unless sum([1,2,3,4]) == 10
#raise 'Invalid input' if sum(["hello"]) == 'Expected array'

puts sum([]) == 0
puts sum([1,2,3]) == 6
puts sum([1,2,3,4]) == 10
puts '---'

#method 2
raise 'max_2_sum([]) != 0 ' unless max_2_sum([]) == 0
raise 'max_2_sum([1,2,3]) !=5' unless max_2_sum([1,2,3]) == 5
raise 'max_2_sum([1,2,3,4]) != 7' unless max_2_sum([1,2,3,4]) == 7
raise 'max_2_sum([1]) != 1' unless max_2_sum([1]) == 1

puts max_2_sum([]) == 0
puts max_2_sum([1,2,3]) == 5
puts max_2_sum([1,3,2,4]) == 7
puts max_2_sum([1]) == 1
puts '---'

#method 3
raise 'sum_to_n?([],2) != false' unless sum_to_n?([],2) == false 
raise 'sum_to_n?([2],2) != false' unless sum_to_n?([2],2) == false
raise 'sum_to_n?([1,2,2,3,3,3,4,4,4,4], 5) != true' unless sum_to_n?([1,2,2,3,3,3,4,4,4,4], 5) == true
raise 'sum_to_n?([1,2,3,4,5,5,6,7,3,2],100) != false' unless sum_to_n?([1,2,3,4,5,5,6,7,3,2],100) == false

puts sum_to_n?([],2) == false
puts sum_to_n?([2],2) == false
puts sum_to_n?([1,2,2,3,3,3,4,4,4,4], 5) == true
puts sum_to_n?([1,2,3,4,5,5,6,7,3,2],100) == false
