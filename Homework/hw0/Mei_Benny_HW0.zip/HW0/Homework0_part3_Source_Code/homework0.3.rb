=begin
create a class BookInStock
BookInStock represents a book with an isbn number (string)
  and a price (floating point number)
The constructor must accept the isbn as the first argument
  and the price as the second argument.
The constructor should raise ArgumentError if the isbn is
  the empty string, or if the price is less than or equal
  to 0. 
Include getters and setters for isbn and price.
Include a method, price_as_string, that returns the price
  of the book with a leading dollar sign and trailing 
  zeroes as a string. e.g. A book worth $20.00 should
  return "$20.00"
=end

CENT = 0.01
QUARTER = 0.25
HALF_DOLLAR = 0.50

class BookInStock
  attr_accessor :isbn
  attr_accessor :price

  def initialize(isbn, price)
    raise ArgumentError if isbn == ''
    raise ArgumentError if price <= 0
    @isbn = isbn
    @price = price
  end

  def price_as_string
    "$%1.2f" % price
  end
end



book = BookInStock.new("isbn", HALF_DOLLAR); puts book.isbn == "isbn" 
  ;puts book.price == HALF_DOLLAR; puts book.price_as_string == "$0.50"

book = BookInStock.new("new", QUARTER); puts book.isbn == "new"
  ;puts book.price == QUARTER; puts book.price_as_string == "$0.25"

book = BookInStock.new("new", CENT); puts book.isbn == "new"
  ;puts book.price == CENT; puts book.price_as_string == "$0.01"

#book = BookInStock.new(1984, "Quarter")
#book = BookInStock.new("", CENT)
#book = BookInStock.new("new", -QUARTER)

