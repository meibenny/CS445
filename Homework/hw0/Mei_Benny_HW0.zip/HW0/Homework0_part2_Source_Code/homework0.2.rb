def hello(name)
	"Hello, " << name
end

def starts_with_consonant?(s)
	if s =~ /\A(?=[^aeiou])(?=[a-z])/i 
		return true
	else
		return false
	end
end

def binary_multiple_of_4?(s)
	return false if s.size == 0
	if s =~ /([^0|1])/
		return false
	else
		s.to_i(2) % 4 == 0
	end
end

puts hello("Benny") == "Hello, Benny"
puts hello("Why") == "Hello, Why"
#puts hello(324798) - RangeError; ArgumentError - check for argument error then it's ok
puts hello("324786") == "Hello, 324786"

puts starts_with_consonant?("consonant") == true
puts starts_with_consonant?("ant") == false
puts starts_with_consonant?("Consonant") == true
puts starts_with_consonant?("Ant ") == false
puts starts_with_consonant?("?SDFSDFDSG#3252#%") == false
#puts starts_with_consonant?(325325325) - false
puts starts_with_consonant?("325768325768532") == false

puts binary_multiple_of_4?("0") == true
puts binary_multiple_of_4?("100") == true
puts binary_multiple_of_4?("10000") == true
puts binary_multiple_of_4?("1000O") == false
puts binary_multiple_of_4?("10000l") == false
puts binary_multiple_of_4?("I00") == false
puts binary_multiple_of_4?("325325") == false
#puts binary_multiple_of_4?(12412414) - ArgumentError
puts binary_multiple_of_4?("1O101010101") == false
puts binary_multiple_of_4?("%^&%$@#%@%#") == false
